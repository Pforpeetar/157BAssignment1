package edu.cs157b.hibernate;

public enum PaymentMethod {
	CASH, VISA, MASTER
}
